SWEET EARNINGS — FREE ANDROID APK BUILD PACKAGE

What this is:
- Your uploaded HTML app is included as app/src/main/assets/index.html.
- A small Android WebView shell opens the HTML locally, inside the app.
- JavaScript, localStorage, and image/file selection are enabled.
- A GitHub Actions workflow is included to build a debug APK for free.

IMPORTANT:
- This ZIP is an Android project, NOT an APK.
- I have not built or installed an APK in this environment.
- The APK must be built using Android build tools; the included GitHub workflow can do that.
- Your records are stored locally by the app. They are not automatically synced to another device.
- Please keep backups using the app's JSON export feature.

BEGINNER BUILD ROUTE (phone-friendly, requires a GitHub account):
1. Create a new GitHub repository named SweetEarningsAndroid.
2. Upload the CONTENTS of this ZIP to the repository (not the ZIP file itself). Keep the .github folder.
3. Open the repository's Actions tab and enable Actions if prompted.
4. Select "Build Sweet Earnings APK" and tap "Run workflow" (or push to main).
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, find "Artifacts", and download "Sweet-Earnings-debug-APK".
7. Extract the downloaded artifact ZIP to get app-debug.apk, then open it on your Android device to install.

If the GitHub screen looks different, send a screenshot and I can guide you one screen at a time.

This first build is a debug APK for personal testing. It is not a Play Store release.
